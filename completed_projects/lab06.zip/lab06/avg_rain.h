#pragma once
int avgRain();