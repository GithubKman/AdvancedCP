// Programming 3, B8, Mr. Test
// Calum Hansen
// 9/8/26
// I wrote this myself with information from canvas and google
// Gets user input (double) for each month then
// calculates the average and prints it.
#include <iostream>
#include <iterator>
#include <string>
#include "input.h"
int avgRain()
{
    double rainfallIn[12];
    std::string month[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
    std::size_t size {std::size(rainfallIn)};
    for (std::size_t i = 0; i < size; ++i)
    {
        double rain { 0.0 };
        std::cout << "Enter the amount of rain received in " << month[i] << ":\n";
        getInput(rain);
        rainfallIn[i] = rain;
    }
    double avgRain { 0.0 };
    for (const auto& rainfall: rainfallIn)
    {
        avgRain += rainfall;
        std::cout << avgRain << '\n';
    }
    avgRain /= std::size(rainfallIn);
    std::cout << "Average rainfall: " << avgRain << "\n";
    return 0;
}